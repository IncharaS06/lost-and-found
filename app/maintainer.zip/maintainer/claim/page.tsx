"use client";

import { useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";

import {
    doc,
    getDoc,
    updateDoc,
    serverTimestamp,
} from "firebase/firestore";
import { auth, db } from "@/app/lib/firebase";
import { onAuthStateChanged } from "firebase/auth";

import { ArrowLeft, ShieldCheck, CheckCircle, XCircle } from "lucide-react";

export default function MaintainerClaimPage() {
    const router = useRouter();
    const sp = useSearchParams();
    const claimId = sp.get("id") || "";

    const [claim, setClaim] = useState<any>(null);
    const [item, setItem] = useState<any>(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const unsub = onAuthStateChanged(auth, async (u) => {
            if (!u || !u.emailVerified) {
                router.replace("/auth");
                return;
            }

            const userSnap = await getDoc(doc(db, "users", u.uid));
            if (!userSnap.exists() || userSnap.data().role !== "maintainer") {
                router.replace("/dashboard");
                return;
            }

            if (!claimId) {
                router.replace("/maintainer");
                return;
            }

            const claimSnap = await getDoc(doc(db, "claims", claimId));
            if (!claimSnap.exists()) {
                router.replace("/maintainer");
                return;
            }

            const c = claimSnap.data();
            setClaim(c);

            const col = c.itemType === "lost" ? "lost_items" : "found_items";
            const itemSnap = await getDoc(doc(db, col, c.itemId));
            if (itemSnap.exists()) setItem(itemSnap.data());

            setLoading(false);
        });

        return () => unsub();
    }, [router, claimId]);

    const updateStatus = async (status: "approved" | "rejected") => {
        await updateDoc(doc(db, "claims", claimId), {
            status,
            reviewedAt: serverTimestamp(),
        });

        if (status === "approved") {
            const col = claim.itemType === "lost" ? "lost_items" : "found_items";
            await updateDoc(doc(db, col, claim.itemId), {
                status: "returned",
                returnedAt: serverTimestamp(),
            });
        }

        alert(`Claim ${status}`);
        router.push("/maintainer");
    };

    if (loading) {
        return (
            <div className="min-h-screen bg-black flex items-center justify-center">
                <p className="text-green-400 text-sm">Loading claim…</p>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gradient-to-br from-gray-950 via-black to-green-950/30 px-4 py-6">
            <div className="max-w-xl mx-auto">
                {/* Top bar */}
                <div className="flex items-center justify-between mb-5">
                    <button
                        onClick={() => router.push("/maintainer")}
                        className="inline-flex items-center gap-2 text-white/70 hover:text-green-300"
                    >
                        <ArrowLeft className="h-4 w-4" />
                        Back
                    </button>

                    <div className="flex items-center gap-2 text-white/70">
                        <ShieldCheck className="h-4 w-4 text-green-400" />
                        <span className="text-xs">Verify Claim</span>
                    </div>
                </div>

                <div className="rounded-xl border border-green-800/30 bg-black/40 p-4 mb-4">
                    <h3 className="text-white font-medium">Item Secret Proof</h3>
                    <p className="text-white/60 text-sm mt-1">
                        {item?.secretProof || "—"}
                    </p>
                </div>

                <div className="rounded-xl border border-green-800/30 bg-black/40 p-4 mb-6">
                    <h3 className="text-white font-medium">Claimant Proof</h3>
                    <p className="text-white/60 text-sm mt-1">
                        {claim?.proofText || "—"}
                    </p>
                </div>

                <div className="flex gap-3">
                    <button
                        onClick={() => updateStatus("approved")}
                        className="flex-1 rounded-xl bg-green-600 hover:bg-green-700 text-white py-3 flex items-center justify-center gap-2"
                    >
                        <CheckCircle className="h-4 w-4" />
                        Approve
                    </button>

                    <button
                        onClick={() => updateStatus("rejected")}
                        className="flex-1 rounded-xl bg-red-600 hover:bg-red-700 text-white py-3 flex items-center justify-center gap-2"
                    >
                        <XCircle className="h-4 w-4" />
                        Reject
                    </button>
                </div>
            </div>
        </div>
    );
}
