"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

import { onAuthStateChanged, signOut } from "firebase/auth";
import { collection, doc, getDoc, onSnapshot, orderBy, query } from "firebase/firestore";
import { auth, db } from "@/app/lib/firebase";

import { ShieldCheck, LogOut, Eye } from "lucide-react";

type Claim = {
    id: string;
    itemType: "lost" | "found";
    itemId: string;
    itemTitle: string;
    category: string;
    location: string;
    claimantEmail: string;
    status: "pending" | "approved" | "rejected";
    createdAt?: any;
};

export default function MaintainerPage() {
    const router = useRouter();
    const [claims, setClaims] = useState<Claim[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const unsubAuth = onAuthStateChanged(auth, async (u) => {
            if (!u || !u.emailVerified) {
                router.replace("/auth");
                return;
            }

            const snap = await getDoc(doc(db, "users", u.uid));
            if (!snap.exists() || snap.data().role !== "maintainer") {
                router.replace("/dashboard");
                return;
            }

            const q = query(
                collection(db, "claims"),
                orderBy("createdAt", "desc")
            );

            const unsub = onSnapshot(q, (snap) => {
                const arr = snap.docs.map((d) => ({
                    id: d.id,
                    ...d.data(),
                })) as Claim[];

                setClaims(arr.filter((c) => c.status === "pending"));
                setLoading(false);
            });

            return () => unsub();
        });
    }, [router]);

    if (loading) {
        return (
            <div className="min-h-screen bg-black flex items-center justify-center">
                <p className="text-green-400 text-sm">Loading maintainer dashboard…</p>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gradient-to-br from-gray-950 via-black to-green-950/30 px-4 py-6">
            {/* Header */}
            <header className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-2 text-white">
                    <ShieldCheck className="h-5 w-5 text-green-400" />
                    <h1 className="font-semibold">Maintainer Dashboard</h1>
                </div>

                <button
                    onClick={async () => {
                        await signOut(auth);
                        router.push("/auth");
                    }}
                    className="flex items-center gap-2 text-white/70 hover:text-red-400"
                >
                    <LogOut className="h-4 w-4" />
                    Logout
                </button>
            </header>

            {/* Claims */}
            <div className="space-y-4">
                {claims.map((c) => (
                    <div
                        key={c.id}
                        className="rounded-xl border border-green-800/30 bg-black/40 p-4"
                    >
                        <div className="flex items-center justify-between">
                            <div>
                                <h3 className="text-white font-medium">{c.itemTitle}</h3>
                                <p className="text-white/60 text-xs">
                                    {c.category} • {c.location}
                                </p>
                                <p className="text-white/40 text-xs mt-1">
                                    Claimant: {c.claimantEmail}
                                </p>
                            </div>

                            <button
                                onClick={() =>
                                    router.push(`/maintainer/claim?id=${c.id}`)
                                }
                                className="inline-flex items-center gap-2 text-green-300 hover:text-green-200 text-sm"
                            >
                                <Eye className="h-4 w-4" />
                                Review
                            </button>
                        </div>
                    </div>
                ))}

                {claims.length === 0 && (
                    <p className="text-center text-white/50 text-sm mt-10">
                        No pending claims 🎉
                    </p>
                )}
            </div>
        </div>
    );
}
